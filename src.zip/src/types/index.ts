export type UserRole = 'company_admin'

export interface AuthUser {
  id: string | number
  name: string
  email: string
  role: UserRole
  status: string
}
