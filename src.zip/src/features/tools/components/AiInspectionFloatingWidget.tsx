import { useEffect, useMemo, useRef, useState } from 'react'
import type { ChangeEvent, FormEvent, ReactNode } from 'react'
import { AxiosError } from 'axios'
import { inspectConstructionImage } from '../api/ai-inspection.api'
import type { AiInspectionResult, AiInspectionType } from '../api/ai-inspection.api'

type InspectionOption = {
  value: AiInspectionType
  label: string
}

const inspectionOptions: InspectionOption[] = [
  { value: 'general', label: 'فحص عام' },
  { value: 'paint', label: 'دهان' },
  { value: 'cement_plaster', label: 'لياسة / طينة' },
  { value: 'tiles', label: 'بلاط وسيراميك' },
  { value: 'ceiling', label: 'أسقف' },
  { value: 'electrical', label: 'كهرباء' },
  { value: 'plumbing', label: 'صحية' },
]

const statusLabels: Record<string, string> = {
  accepted: 'مقبول',
  approved: 'مقبول',
  pass: 'مقبول',
  passed: 'مقبول',
  rejected: 'مرفوض',
  reject: 'مرفوض',
  failed: 'مرفوض',
  warning: 'بحاجة مراجعة',
  pending: 'بحاجة مراجعة',
}

function getStatusLabel(status?: string) {
  if (!status) {
    return 'غير محدد'
  }

  return statusLabels[status.toLowerCase()] ?? status
}

function getStatusClass(status?: string) {
  const normalizedStatus = status?.toLowerCase() ?? ''

  if (['accepted', 'approved', 'pass', 'passed'].includes(normalizedStatus)) {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700'
  }

  if (['rejected', 'reject', 'failed'].includes(normalizedStatus)) {
    return 'border-red-200 bg-red-50 text-red-700'
  }

  return 'border-amber-200 bg-amber-50 text-amber-700'
}

function getErrorMessage(error: unknown) {
  if (error instanceof AxiosError) {
    const data = error.response?.data as { message?: string; errors?: Record<string, string[]> } | undefined
    const validationMessage = data?.errors ? Object.values(data.errors).flat()[0] : undefined
    return validationMessage || data?.message || 'تعذر تحليل الصورة. تأكد من الصورة ثم حاول مرة ثانية.'
  }

  if (error instanceof Error) {
    return error.message
  }

  return 'حدث خطأ غير متوقع أثناء تحليل الصورة.'
}

function formatPercent(value?: number) {
  const numberValue = Number(value ?? 0)

  if (Number.isNaN(numberValue)) {
    return '0%'
  }

  return `${new Intl.NumberFormat('ar-SY', { maximumFractionDigits: 0 }).format(numberValue)}%`
}

function clampPercent(value?: number) {
  const numberValue = Number(value ?? 0)

  if (Number.isNaN(numberValue)) {
    return 0
  }

  return Math.max(0, Math.min(100, numberValue))
}

export function AiInspectionFloatingWidget() {
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)
  const requestIdRef = useRef(0)
  const [isOpen, setIsOpen] = useState(false)
  const [inspectionType, setInspectionType] = useState<AiInspectionType>('general')
  const [image, setImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [result, setResult] = useState<AiInspectionResult | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const hasFinishedInspection = Boolean(result?.report)
  const selectedTypeLabel = useMemo(
    () => inspectionOptions.find((option) => option.value === inspectionType)?.label ?? 'فحص عام',
    [inspectionType]
  )

  useEffect(() => {
    return () => {
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview)
      }
    }
  }, [imagePreview])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [isOpen, isSubmitting, result, errorMessage, imagePreview])

  function resetFileInput() {
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  function clearImageOnly() {
    setImage(null)
    setImagePreview(null)
    resetFileInput()
  }

  function startAnotherInspection() {
    requestIdRef.current += 1
    setResult(null)
    setErrorMessage(null)
    setIsSubmitting(false)
    clearImageOnly()
  }

  function handleImageChange(event: ChangeEvent<HTMLInputElement>) {
    const selectedFile = event.target.files?.[0]
    setErrorMessage(null)

    if (isSubmitting || hasFinishedInspection) {
      resetFileInput()
      return
    }

    if (!selectedFile) {
      clearImageOnly()
      return
    }

    if (!selectedFile.type.startsWith('image/')) {
      clearImageOnly()
      setErrorMessage('اختار ملف صورة فقط.')
      return
    }

    setImage(selectedFile)
    setImagePreview(URL.createObjectURL(selectedFile))
    setResult(null)
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setErrorMessage(null)

    if (isSubmitting || hasFinishedInspection) {
      return
    }

    if (!image) {
      setErrorMessage('ارفع صورة واضحة قبل بدء الفحص.')
      return
    }

    const activeRequestId = requestIdRef.current + 1
    requestIdRef.current = activeRequestId
    setIsSubmitting(true)
    setResult(null)

    try {
      const response = await inspectConstructionImage({ image, inspectionType })

      if (requestIdRef.current === activeRequestId) {
        setResult(response)
      }
    } catch (error) {
      if (requestIdRef.current === activeRequestId) {
        setErrorMessage(getErrorMessage(error))
      }
    } finally {
      if (requestIdRef.current === activeRequestId) {
        setIsSubmitting(false)
      }
    }
  }

  return (
    <div className="fixed bottom-5 left-5 z-50 print:hidden" dir="rtl">
      {isOpen ? (
        <section className="fixed bottom-24 left-4 right-4 flex h-[min(680px,calc(100vh-7rem))] max-w-[430px] flex-col overflow-hidden rounded-[1.7rem] border border-slate-200 bg-white text-right shadow-[0_24px_80px_rgba(15,23,42,0.22)] sm:left-5 sm:right-auto sm:w-[430px]">
          <header className="flex items-center justify-between gap-3 border-b border-slate-200 bg-white px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#eef4eb] text-[#50683f]">
                <RobotIcon />
              </span>
              <div>
                <h2 className="text-sm font-extrabold text-slate-950">مساعد فحص الإكساء</h2>
                <p className="mt-0.5 text-xs font-semibold text-slate-500">ارفع صورة وخذ تقرير مختصر</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
              aria-label="إغلاق نافذة الفحص"
              title="إغلاق"
            >
              <CloseIcon />
            </button>
          </header>

          <div ref={scrollRef} className="min-h-0 flex-1 space-y-4 overflow-y-auto bg-slate-50/70 px-4 py-4">
            <AssistantBubble>
              <p className="text-sm font-bold leading-7 text-slate-700">اختار نوع الفحص وارفع صورة واضحة من الموقع. بعد صدور التقرير، استخدم زر فحص صورة أخرى لبدء تحليل جديد.</p>
            </AssistantBubble>

            {imagePreview ? (
              <UserBubble>
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
                  <img src={imagePreview} alt="صورة الفحص" className="max-h-48 w-full object-cover" />
                </div>
                <div className="mt-2 flex items-center justify-between gap-2 text-xs font-bold text-slate-500">
                  <span className="truncate">{image?.name}</span>
                  {!isSubmitting && !hasFinishedInspection ? (
                    <button type="button" onClick={clearImageOnly} className="text-red-500 transition hover:text-red-600">
                      إزالة
                    </button>
                  ) : (
                    <span className="text-[#50683f]">الصورة قيد التقرير</span>
                  )}
                </div>
              </UserBubble>
            ) : null}

            {isSubmitting ? <LoadingBubble label={selectedTypeLabel} /> : null}

            {errorMessage ? (
              <AssistantBubble tone="danger">
                <p className="text-sm font-bold leading-7">{errorMessage}</p>
              </AssistantBubble>
            ) : null}

            {!isSubmitting && result?.report ? <ReportBubble result={result} /> : null}
          </div>

          <form onSubmit={handleSubmit} className="border-t border-slate-200 bg-white p-3">
            {hasFinishedInspection ? (
              <button
                type="button"
                onClick={startAnotherInspection}
                className="flex h-11 w-full items-center justify-center gap-2 rounded-2xl bg-[#50683f] px-4 text-sm font-extrabold text-white shadow-sm transition hover:bg-[#425734]"
              >
                <RefreshIcon />
                افحص صورة أخرى
              </button>
            ) : (
              <div className="grid gap-2">
                <select
                  value={inspectionType}
                  onChange={(event) => setInspectionType(event.target.value as AiInspectionType)}
                  disabled={isSubmitting}
                  className="h-11 rounded-2xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 outline-none transition focus:border-[#50683f] focus:ring-4 focus:ring-[#50683f]/10 disabled:cursor-not-allowed disabled:bg-slate-50"
                >
                  {inspectionOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>

                <div className="flex items-center gap-2">
                  <input ref={fileInputRef} type="file" accept="image/*" className="sr-only" onChange={handleImageChange} disabled={isSubmitting} />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isSubmitting}
                    className="flex h-11 shrink-0 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 text-xs font-extrabold text-slate-600 transition hover:bg-slate-50 hover:text-[#50683f] disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    <ImageIcon />
                    صورة
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting || !image}
                    className="flex h-11 flex-1 items-center justify-center gap-2 rounded-2xl bg-[#50683f] px-4 text-sm font-extrabold text-white shadow-sm transition hover:bg-[#425734] disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    {isSubmitting ? 'جاري الفحص...' : 'افحص الصورة'}
                    <SendIcon />
                  </button>
                </div>
              </div>
            )}
          </form>
        </section>
      ) : null}

      <button
        type="button"
        onClick={() => setIsOpen((value) => !value)}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-[#50683f] text-white shadow-[0_18px_45px_rgba(80,104,63,0.35)] transition hover:-translate-y-0.5 hover:bg-[#425734] focus:outline-none focus:ring-4 focus:ring-[#50683f]/20"
        aria-label="فتح مساعد فحص الإكساء"
        title="مساعد الفحص"
      >
        <RobotIcon />
      </button>
    </div>
  )
}

function AssistantBubble({ children, tone = 'default' }: { children: ReactNode; tone?: 'default' | 'danger' }) {
  return (
    <div className="flex justify-start">
      <div className={`max-w-[92%] rounded-3xl rounded-br-lg border px-4 py-3 shadow-sm ${tone === 'danger' ? 'border-red-100 bg-red-50 text-red-700' : 'border-slate-200 bg-white'}`}>
        {children}
      </div>
    </div>
  )
}

function UserBubble({ children }: { children: ReactNode }) {
  return (
    <div className="flex justify-end">
      <div className="max-w-[86%] rounded-3xl rounded-bl-lg border border-[#50683f]/20 bg-[#eef4eb] px-3 py-3 shadow-sm">{children}</div>
    </div>
  )
}

function LoadingBubble({ label }: { label: string }) {
  const steps = ['قراءة الصورة', `مطابقة نوع الفحص: ${label}`, 'تحديد العيوب الأهم', 'تجهيز التقرير']

  return (
    <AssistantBubble>
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[#eef4eb] text-[#50683f]">
            <span className="absolute inset-0 animate-ping rounded-2xl bg-[#50683f]/10" />
            <ScanIcon />
          </span>
          <div>
            <p className="text-sm font-extrabold text-slate-900">عم نحلل الصورة</p>
            <p className="mt-0.5 text-xs font-semibold text-slate-500">ثواني وبيطلع التقرير المختصر.</p>
          </div>
        </div>
        <div className="space-y-2">
          {steps.map((step, index) => (
            <div key={step} className="rounded-2xl bg-slate-50 px-3 py-2">
              <div className="flex items-center justify-between gap-2 text-xs font-extrabold text-slate-600">
                <span>{step}</span>
                <span className="text-[#50683f]">0{index + 1}</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200" dir="ltr">
                <div className="h-full w-2/3 animate-pulse rounded-full bg-[#50683f]" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </AssistantBubble>
  )
}

function ReportBubble({ result }: { result: AiInspectionResult }) {
  const report = result.report ?? {}
  const score = clampPercent(report.score)
  const confidence = clampPercent(report.confidence)
  const defects = (report.confirmed_defects ?? []).filter(Boolean)
  const recommendations = (report.recommendations ?? []).filter(Boolean)
  const observations = (report.visual_observations ?? []).filter(Boolean).slice(0, 2)

  return (
    <AssistantBubble>
      <div className="space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-extrabold text-slate-400">نتيجة الفحص</p>
            <h3 className="mt-1 text-lg font-extrabold text-slate-950">{getStatusLabel(report.status)}</h3>
          </div>
          <span className={`rounded-full border px-3 py-1 text-xs font-extrabold ${getStatusClass(report.status)}`}>{getStatusLabel(report.status)}</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <MiniMeter label="الجودة" value={score} display={formatPercent(report.score)} />
          <MiniMeter label="الثقة" value={confidence} display={formatPercent(report.confidence)} />
        </div>

        {report.summary ? (
          <section className="rounded-2xl bg-slate-50 px-3 py-3">
            <h4 className="text-xs font-extrabold text-slate-500">الملخص</h4>
            <p className="mt-2 text-sm font-bold leading-7 text-slate-700">{report.summary}</p>
          </section>
        ) : null}

        <div className="grid grid-cols-3 gap-2">
          <SmallStat label="عيوب" value={defects.length} />
          <SmallStat label="توصيات" value={recommendations.length} />
          <SmallStat label="ملاحظات" value={observations.length} />
        </div>

        <CompactList title="العيوب الأهم" items={defects} dotClass="bg-red-500" />
        <CompactList title="التوصيات" items={recommendations} dotClass="bg-[#50683f]" />
        <CompactList title="ملاحظات سريعة" items={observations} dotClass="bg-slate-400" />
      </div>
    </AssistantBubble>
  )
}

function MiniMeter({ label, value, display }: { label: string; value: number; display: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white px-3 py-3">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-extrabold text-slate-500">{label}</span>
        <span className="text-sm font-extrabold text-slate-950" dir="ltr">{display}</span>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100" dir="ltr">
        <div className="h-full rounded-full bg-[#50683f]" style={{ width: `${value}%` }} />
      </div>
    </div>
  )
}

function SmallStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-slate-50 px-3 py-2 text-center">
      <p className="text-lg font-extrabold text-slate-950">{value}</p>
      <p className="text-[11px] font-bold text-slate-500">{label}</p>
    </div>
  )
}

function CompactList({ title, items, dotClass }: { title: string; items: string[]; dotClass: string }) {
  const visibleItems = items.filter(Boolean).slice(0, 4)

  if (visibleItems.length === 0) {
    return null
  }

  return (
    <section>
      <h4 className="text-xs font-extrabold text-slate-500">{title}</h4>
      <ul className="mt-2 space-y-2">
        {visibleItems.map((item, index) => (
          <li key={`${title}-${index}`} className="flex gap-2 rounded-2xl bg-slate-50 px-3 py-2 text-xs font-bold leading-6 text-slate-700">
            <span className={`mt-2 h-1.5 w-1.5 shrink-0 rounded-full ${dotClass}`} />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </section>
  )
}

function RobotIcon() {
  return (
    <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M12 3v3" strokeLinecap="round" />
      <path d="M8 6h8a4 4 0 0 1 4 4v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5v-5a4 4 0 0 1 4-4Z" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M9 13h.01M15 13h.01" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M9.5 17h5" strokeLinecap="round" />
      <path d="M4 12H2M22 12h-2" strokeLinecap="round" />
      <path d="M12 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z" fill="currentColor" stroke="none" />
    </svg>
  )
}

function CloseIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
    </svg>
  )
}

function ImageIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M4 5h16v14H4z" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8 13l2.2-2.2L15 16M14 13l1.5-1.5L20 16M8 9h.1" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function SendIcon() {
  return (
    <svg className="h-5 w-5 rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function ScanIcon() {
  return (
    <svg className="relative h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M7 4H5a1 1 0 0 0-1 1v2M17 4h2a1 1 0 0 1 1 1v2M7 20H5a1 1 0 0 1-1-1v-2M17 20h2a1 1 0 0 0 1-1v-2M7 12h10" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function RefreshIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M20 6v5h-5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M4 18v-5h5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M18.2 9A7 7 0 0 0 6.3 6.7L4 9M5.8 15a7 7 0 0 0 11.9 2.3L20 15" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
