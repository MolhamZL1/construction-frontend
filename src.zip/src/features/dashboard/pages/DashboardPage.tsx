import { useAuthStore } from '@/stores/authStore'

const stats = [
  { label: 'المشاريع', value: '12', note: 'مفتوحة هذا الشهر' },
  { label: 'المهام النشطة', value: '27', note: 'تحتاج متابعة يومية' },
  { label: 'التنبيهات', value: '5', note: 'بينها 2 عاجلة' },
]

export function DashboardPage() {
  const user = useAuthStore((state) => state.user)

  return (
    <section className="space-y-8" dir="rtl">
      <div className="rounded-[2rem] bg-linear-to-l from-slate-950 via-slate-800 to-emerald-700 p-8 text-white shadow-lg">
        <p className="text-sm text-white/70">لوحة التحكم</p>
        <h1 className="mt-3 text-3xl font-bold">أهلاً {user?.name}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-7 text-white/80">
          هذه نظرة سريعة على حالة أعمال الشركة اليوم، مع مؤشرات مباشرة للمشاريع والمهام والتنبيهات.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {stats.map((item) => (
          <div key={item.label} className="rounded-[1.75rem] border border-slate-200 bg-white p-6 shadow-sm">
            <p className="text-sm text-slate-500">{item.label}</p>
            <p className="mt-4 text-4xl font-bold text-slate-950">{item.value}</p>
            <p className="mt-3 text-sm text-slate-500">{item.note}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
