import { api } from '@/lib/axios'
import type {
  AddWorkItemCommentPayload,
  EquipmentBookingPayload,
  FinishEquipmentBookingPayload,
  PendingWorkItemUpdate,
  ReorderWorkItemPayload,
  UpdateWorkItemInlinePayload,
  UpdateWorkItemProgressPayload,
  UpsertWorkItemPayload,
  WorkItem,
  WorkItemApiResponse,
  WorkItemComment,
  WorkItemCommentApiResponse,
  WorkItemEquipmentBooking,
} from '../models/work-item.model'
import { mapWorkItem, mapWorkItemComment, toNullableNumber } from '../utils/work-items-formatters'

interface ApiEnvelope<T> {
  status?: number
  message?: string
  data: T
}

interface EquipmentBookingApiResponse {
  id: number | string
  name?: string | null
  type?: string | null
  identifier_no?: string | null
  work_item_id?: number | string | null
  equipment_id?: number | string | null
  project_id?: number | string | null
  status?: string | null
  start_date?: string | null
  end_date?: string | null
  duration_days?: number | string | null
  notes?: string | null
  booking?: {
    id?: number | string | null
    status?: string | null
    start_date?: string | null
    end_date?: string | null
    duration_days?: number | string | null
    notes?: string | null
    work_item?: {
      id?: number | string | null
      name?: string | null
    } | null
    project?: {
      id?: number | string | null
      name?: string | null
    } | null
    booked_by?: {
      id?: number | string | null
      name?: string | null
    } | null
  } | null
  current_booking?: {
    id?: number | string | null
    status?: string | null
    start_date?: string | null
    end_date?: string | null
    duration_days?: number | string | null
    notes?: string | null
    work_item?: {
      id?: number | string | null
      name?: string | null
    } | null
    project?: {
      id?: number | string | null
      name?: string | null
    } | null
    booked_by?: {
      id?: number | string | null
      name?: string | null
    } | null
  } | null
  work_item?: {
    id?: number | string | null
    name?: string | null
  } | null
  project?: {
    id?: number | string | null
    name?: string | null
  } | null
  equipment?: {
    id?: number | string
    name?: string | null
    type?: string | null
    identifier_no?: string | null
    status?: string | null
  } | null
  booked_by?: {
    id?: number | string
    name?: string | null
  } | null
}

function normalizeListPayload(payload: unknown): WorkItemApiResponse[] {
  if (Array.isArray(payload)) return payload as WorkItemApiResponse[]

  if (payload && typeof payload === 'object') {
    const data = payload as { work_items?: WorkItemApiResponse[]; items?: WorkItemApiResponse[]; data?: WorkItemApiResponse[] }
    return data.work_items ?? data.items ?? data.data ?? []
  }

  return []
}

function normalizeCommentsPayload(payload: unknown): WorkItemCommentApiResponse[] {
  if (Array.isArray(payload)) return payload as WorkItemCommentApiResponse[]

  if (payload && typeof payload === 'object') {
    const data = payload as { comments?: WorkItemCommentApiResponse[]; data?: WorkItemCommentApiResponse[] }
    return data.comments ?? data.data ?? []
  }

  return []
}

function normalizeBookingsPayload(payload: unknown): EquipmentBookingApiResponse[] {
  if (Array.isArray(payload)) return payload as EquipmentBookingApiResponse[]

  if (payload && typeof payload === 'object') {
    const data = payload as {
      bookings?: EquipmentBookingApiResponse[]
      equipment_bookings?: EquipmentBookingApiResponse[]
      current_bookings?: EquipmentBookingApiResponse[]
      equipment?: EquipmentBookingApiResponse[] | EquipmentBookingApiResponse
      data?: EquipmentBookingApiResponse[]
      booking?: EquipmentBookingApiResponse
    }

    const equipment = data.equipment
    if (Array.isArray(equipment)) return equipment
    if (equipment && typeof equipment === 'object') return [equipment]

    if (data.booking && typeof data.booking === 'object') return [data.booking]

    return data.bookings ?? data.equipment_bookings ?? data.current_bookings ?? data.data ?? []
  }

  return []
}

function getBookingDuration(startDate?: string | null, endDate?: string | null) {
  if (!startDate) return null
  const start = new Date(`${startDate}T00:00:00`)
  const end = endDate ? new Date(`${endDate}T00:00:00`) : new Date()
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return null
  const diff = Math.ceil((end.getTime() - start.getTime()) / 86_400_000) + 1
  return diff > 0 ? diff : 1
}

function mapEquipmentBooking(item: EquipmentBookingApiResponse): WorkItemEquipmentBooking {
  const booking = item.booking ?? item.current_booking ?? null
  const equipmentId = item.equipment_id ?? item.equipment?.id ?? item.id
  const workItem = booking?.work_item ?? item.work_item
  const bookedBy = booking?.booked_by ?? item.booked_by
  const startDate = booking?.start_date ?? item.start_date ?? null
  const endDate = booking?.end_date ?? item.end_date ?? null

  return {
    id: String(booking?.id ?? item.id),
    workItemId: item.work_item_id == null ? (workItem?.id == null ? undefined : String(workItem.id)) : String(item.work_item_id),
    equipmentId: equipmentId == null ? undefined : String(equipmentId),
    equipmentName: item.equipment?.name ?? item.name ?? `معدة #${equipmentId ?? ''}`,
    equipmentType: item.equipment?.type ?? item.type ?? undefined,
    equipmentIdentifier: item.equipment?.identifier_no ?? item.identifier_no ?? undefined,
    status: booking?.status ?? item.status ?? 'active',
    startDate,
    endDate,
    durationDays: toNullableNumber(booking?.duration_days ?? item.duration_days) ?? getBookingDuration(startDate, endDate),
    bookedByName: bookedBy?.name ?? undefined,
  }
}


export async function listWorkItems(projectId: string): Promise<WorkItem[]> {
  const response = await api.get<ApiEnvelope<unknown>>(`/projects/${projectId}/work-items`)
  return normalizeListPayload(response.data.data).map(mapWorkItem)
}

export async function createWorkItem(projectId: string, payload: UpsertWorkItemPayload): Promise<WorkItem> {
  const response = await api.post<ApiEnvelope<WorkItemApiResponse>>(`/projects/${projectId}/work-items`, payload)
  return mapWorkItem(response.data.data)
}

export async function updateWorkItemInline(projectId: string, workItemId: string, payload: UpdateWorkItemInlinePayload): Promise<WorkItem> {
  const response = await api.post<ApiEnvelope<WorkItemApiResponse>>(`/projects/${projectId}/work-items/${workItemId}`, payload)
  return mapWorkItem(response.data.data)
}

export async function deactivateWorkItem(projectId: string, workItemId: string): Promise<WorkItem> {
  return updateWorkItemInline(projectId, workItemId, { is_active: 0 })
}

export async function activateWorkItem(projectId: string, workItemId: string): Promise<WorkItem> {
  return updateWorkItemInline(projectId, workItemId, { is_active: 1 })
}

export async function deleteWorkItem(workItemId: string): Promise<void> {
  await api.delete(`/work-items/${workItemId}`)
}

export async function reorderWorkItems(projectId: string, payload: ReorderWorkItemPayload): Promise<WorkItem[]> {
  const response = await api.put<ApiEnvelope<unknown>>(`/projects/${projectId}/work-items/reorder`, payload)
  return normalizeListPayload(response.data.data).map(mapWorkItem)
}

export async function startWorkItem(projectId: string, workItemId: string): Promise<WorkItem> {
  const response = await api.post<ApiEnvelope<WorkItemApiResponse>>(`/projects/${projectId}/work-items/${workItemId}/start`)
  return mapWorkItem(response.data.data)
}

export async function completeWorkItem(projectId: string, workItemId: string, delayReason?: string): Promise<WorkItem> {
  const payload = delayReason?.trim() ? { delay_reason: delayReason.trim() } : undefined
  const response = await api.post<ApiEnvelope<WorkItemApiResponse>>(`/projects/${projectId}/work-items/${workItemId}/complete`, payload)
  return mapWorkItem(response.data.data)
}

export async function listPendingWorkItemUpdates(): Promise<PendingWorkItemUpdate[]> {
  const response = await api.get<ApiEnvelope<Array<Record<string, unknown>>>>('/work-item-details/pending')
  return (response.data.data ?? []).map((item) => ({
    workItemId: String(item.work_item_id),
    workItemName: String(item.work_item_name ?? 'بند غير معروف'),
    project: item.project && typeof item.project === 'object'
      ? {
          id: String((item.project as { id?: unknown }).id ?? ''),
          name: String((item.project as { name?: unknown }).name ?? ''),
        }
      : undefined,
    requestedAt: item.requested_at ? String(item.requested_at) : undefined,
    updates: Array.isArray(item.updates)
      ? item.updates.map((update) => ({
          detailId: String((update as { detail_id?: unknown }).detail_id ?? ''),
          field: String((update as { field?: unknown }).field ?? ''),
          currentValue: ((update as { current_value?: string | number | null }).current_value ?? null),
          requestedValue: ((update as { requested_value?: string | number | null }).requested_value ?? null),
        }))
      : [],
  }))
}

export async function approveWorkItemUpdates(workItemId: string): Promise<void> {
  await api.post(`/work-items/${workItemId}/approve`)
}

export async function rejectWorkItemUpdates(workItemId: string, reason: string): Promise<void> {
  await api.post(`/work-items/${workItemId}/reject`, { reason })
}

export async function listWorkItemComments(workItemId: string): Promise<WorkItemComment[]> {
  const response = await api.get<ApiEnvelope<unknown>>(`/work-items/${workItemId}/comments`)
  return normalizeCommentsPayload(response.data.data).map(mapWorkItemComment)
}

export async function addWorkItemComment(payload: AddWorkItemCommentPayload): Promise<WorkItemComment> {
  const formData = new FormData()
  formData.append('comment', payload.body)

  const response = await api.post<ApiEnvelope<{ comment?: WorkItemCommentApiResponse } | WorkItemCommentApiResponse>>(
    `/work-items/${payload.workItemId}/comments`,
    formData
  )

  const data = response.data.data
  const comment = data && typeof data === 'object' && 'comment' in data
    ? (data as { comment: WorkItemCommentApiResponse }).comment
    : data

  return mapWorkItemComment(comment as WorkItemCommentApiResponse)
}

function appendProgressValue(formData: FormData, key: string, value: string | number | boolean | null | undefined) {
  if (value === null || value === undefined || value === '') return
  formData.append(key, typeof value === 'boolean' ? (value ? '1' : '0') : String(value))
}

function isImageFile(file: File) {
  return file instanceof File && file.type.startsWith('image/')
}

async function postProgressFormData(endpoint: string, formData: FormData) {
  return api.post<ApiEnvelope<unknown>>(endpoint, formData, {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
    },
  })
}

export async function updateWorkItemProgress(payload: UpdateWorkItemProgressPayload): Promise<void> {
  const formData = new FormData()

  Object.entries(payload.values ?? {}).forEach(([key, value]) => {
    appendProgressValue(formData, key, value)
  })

  ;(payload.images ?? [])
    .filter(isImageFile)
    .forEach((file) => formData.append('photos[]', file, file.name))

  const endpoint = payload.spaceId
    ? `/projects/${payload.projectId}/work-items/${payload.workItemId}/progress-requests/room/${payload.spaceId}`
    : `/projects/${payload.projectId}/work-items/${payload.workItemId}/progress-requests`

  await postProgressFormData(endpoint, formData)
}

export async function bookEquipment(payload: EquipmentBookingPayload): Promise<void> {
  const formData = new FormData()
  formData.append('equipment_id', payload.equipmentId)
  formData.append('work_item_id', payload.workItemId)
  formData.append('start_date', payload.startDate)
  if (payload.notes?.trim()) formData.append('notes', payload.notes.trim())

  await api.post('/equipment-bookings', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export async function finishEquipmentBooking(payload: FinishEquipmentBookingPayload): Promise<void> {
  const formData = new FormData()
  formData.append('end_date', payload.endDate)

  await api.post(`/equipment-bookings/${payload.bookingId}/finish`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

interface EquipmentDetailsBookingDatesResponse {
  data?: {
    equipment?: {
      current_booking?: {
        id?: number | string | null
        status?: string | null
        start_date?: string | null
        end_date?: string | null
        duration_days?: number | string | null
        work_item?: { id?: number | string | null; name?: string | null } | null
        booked_by?: { id?: number | string | null; name?: string | null } | null
      } | null
      booking_history?: Array<{
        id?: number | string | null
        status?: string | null
        start_date?: string | null
        end_date?: string | null
        work_item?: string | { id?: number | string | null; name?: string | null } | null
        project?: string | { id?: number | string | null; name?: string | null } | null
      }> | null
    }
  }
}

function normalizeBookingStatus(value?: string | null) {
  return String(value ?? '').trim().toLowerCase()
}

function isFinishedBookingStatus(value?: string | null) {
  const status = normalizeBookingStatus(value)
  return ['completed', 'finished', 'ended', 'closed', 'available'].includes(status)
}

function getBookingWorkItemId(item: EquipmentBookingApiResponse): string {
  const raw = item as EquipmentBookingApiResponse & {
    current_booking?: { work_item?: { id?: number | string | null } | null } | null
  }

  return String(raw.current_booking?.work_item?.id ?? item.work_item?.id ?? item.work_item_id ?? '')
}

function historyBelongsToWorkItem(historyItem: { work_item?: string | { id?: number | string | null; name?: string | null } | null }, workItemId: string) {
  if (!historyItem.work_item) return false
  if (typeof historyItem.work_item === 'string') return true
  return String(historyItem.work_item.id ?? '') === workItemId
}

async function readEquipmentBookingDates(equipmentId: string, workItemId: string): Promise<Partial<WorkItemEquipmentBooking>> {
  try {
    const response = await api.get<EquipmentDetailsBookingDatesResponse>(`/equipment/${equipmentId}`)
    const equipment = response.data.data?.equipment
    const current = equipment?.current_booking
    const bookingHistory = equipment?.booking_history ?? []
    const latestHistoryForThisWorkItem = bookingHistory.find((historyItem) => historyBelongsToWorkItem(historyItem, workItemId)) ?? null

    if (current) {
      const currentBelongsToWorkItem = current.work_item?.id == null || String(current.work_item.id) === workItemId
      if (currentBelongsToWorkItem && !isFinishedBookingStatus(current.status) && !current.end_date) {
        return {
          id: current.id != null ? String(current.id) : undefined,
          status: current.status ?? 'active',
          startDate: current.start_date ?? undefined,
          endDate: current.end_date ?? null,
          durationDays: current.duration_days != null ? toNullableNumber(current.duration_days) : undefined,
          bookedByName: current.booked_by?.name ?? undefined,
          previousBookingStartDate: latestHistoryForThisWorkItem?.start_date ?? null,
          previousBookingEndDate: latestHistoryForThisWorkItem?.end_date ?? null,
          previousBookingStatus: latestHistoryForThisWorkItem?.status ?? null,
          isCurrentBooking: true,
        }
      }
    }

    if (latestHistoryForThisWorkItem) {
      return {
        status: latestHistoryForThisWorkItem.status ?? 'completed',
        startDate: latestHistoryForThisWorkItem.start_date ?? undefined,
        endDate: latestHistoryForThisWorkItem.end_date ?? null,
        previousBookingStartDate: latestHistoryForThisWorkItem.start_date ?? null,
        previousBookingEndDate: latestHistoryForThisWorkItem.end_date ?? null,
        previousBookingStatus: latestHistoryForThisWorkItem.status ?? null,
        isCurrentBooking: false,
      }
    }

    return { isCurrentBooking: false }
  } catch {
    return {}
  }
}

function isActiveEquipmentBooking(booking: WorkItemEquipmentBooking) {
  return Boolean(booking.isCurrentBooking ?? (!isFinishedBookingStatus(booking.status) && !booking.endDate))
}

export async function listWorkItemEquipmentBookings(workItemId: string): Promise<WorkItemEquipmentBooking[]> {
  const response = await api.get<ApiEnvelope<unknown>>('/equipment/by-status', { params: { status: 'Booked' } })
  const baseBookings = normalizeBookingsPayload(response.data.data)
    .filter((item) => getBookingWorkItemId(item) === workItemId)
    .map(mapEquipmentBooking)

  const bookingsWithDetails = await Promise.all(baseBookings.map(async (booking) => {
    if (!booking.equipmentId) return booking
    const dates = await readEquipmentBookingDates(booking.equipmentId, workItemId)

    return {
      ...booking,
      ...dates,
      id: dates.id ?? booking.id,
      startDate: dates.startDate ?? booking.startDate,
      endDate: dates.endDate ?? booking.endDate,
      durationDays: dates.durationDays ?? booking.durationDays,
      bookedByName: dates.bookedByName ?? booking.bookedByName,
    }
  }))

  return bookingsWithDetails.filter(isActiveEquipmentBooking)
}


