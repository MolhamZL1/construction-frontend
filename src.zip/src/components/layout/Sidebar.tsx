import { NavLink } from 'react-router-dom'
import { cn } from '@/utils/cn'

const links = [
  {
    label: 'لوحة التحكم',
    to: '/dashboard',
  },
]

export function Sidebar() {
  return (
    <aside className="h-screen w-72 border-l border-slate-200 bg-slate-950 p-5 text-white" dir="rtl">
      <div className="mb-10 rounded-3xl border border-white/10 bg-white/5 p-5">
        <p className="text-xs tracking-[0.3em] text-slate-400">CLADDING SYSTEM</p>
        <h1 className="mt-3 text-xl font-bold">نظام إدارة الشركات</h1>
        <p className="mt-2 text-sm text-slate-400">لوحة تشغيل سريعة لمتابعة المشاريع والمهام</p>
      </div>

      <nav className="space-y-2">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              cn(
                'block rounded-2xl px-4 py-3 text-sm font-medium transition',
                isActive
                  ? 'bg-white text-slate-950'
                  : 'text-slate-300 hover:bg-white/10 hover:text-white'
              )
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
