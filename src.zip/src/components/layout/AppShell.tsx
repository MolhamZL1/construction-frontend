import { Outlet, useNavigate } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { AiInspectionFloatingWidget } from '@/features/tools'
import { useSignOut } from '@/features/auth/hooks/useLoginCompany'
import { NotificationsMenu } from '@/features/notifications'
import { useAutoSyncFcmToken, useForegroundNotifications } from '@/features/notifications/hooks/useNotifications'
import { queryClient } from '@/lib/query-client'
import { useAuthStore } from '@/stores/authStore'

export function AppShell() {
  const navigate = useNavigate()
  const logout = useAuthStore((state) => state.logout)

  const signOutMutation = useSignOut()

  useAutoSyncFcmToken()
  useForegroundNotifications()

  async function handleLogout() {
    try {
      await signOutMutation.mutateAsync()
    } catch {
      // Local logout is still required if the server session is already expired.
    } finally {
      logout()
      queryClient.clear()
      navigate('/login', { replace: true })
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 lg:flex-row" dir="rtl">
      <Sidebar />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4 shadow-[0_1px_4px_rgba(15,23,42,0.08)] sm:px-6" dir="ltr">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleLogout}
              disabled={signOutMutation.isPending}
              className="flex h-10 items-center gap-2 rounded-xl bg-[#eef4eb] px-3 text-sm font-medium text-[#50683f] transition hover:bg-[#e1ebdc] disabled:cursor-not-allowed disabled:opacity-60"
              aria-label="تسجيل الخروج"
              title="تسجيل الخروج"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M15 17l5-5-5-5M20 12H9M11 20H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span>{signOutMutation.isPending ? 'جاري الخروج...' : 'تسجيل الخروج'}</span>
            </button>

            <button
              type="button"
              className="hidden h-10 w-10 items-center justify-center rounded-xl text-slate-500 transition hover:bg-slate-100 sm:flex"
              aria-label="الإعدادات"
              title="الإعدادات"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" />
                <path d="M19 12a7.5 7.5 0 0 0-.1-1.1l2-1.5-2-3.4-2.4 1a8 8 0 0 0-1.9-1.1L14.3 3h-4l-.4 2.9A8 8 0 0 0 8 7L5.6 6l-2 3.4 2 1.5A7.5 7.5 0 0 0 5.5 12c0 .4 0 .8.1 1.1l-2 1.5 2 3.4L8 17a8 8 0 0 0 1.9 1.1l.4 2.9h4l.4-2.9a8 8 0 0 0 1.9-1.1l2.4 1 2-3.4-2-1.5c.1-.3.1-.7.1-1.1Z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>

            <NotificationsMenu />
          </div>
        </header>

        <main className="min-h-0 flex-1 bg-slate-50">
          <Outlet />
        </main>
        <AiInspectionFloatingWidget />
      </div>
    </div>
  )
}
