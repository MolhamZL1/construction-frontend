import { Outlet, useNavigate } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { useAuthStore } from '@/stores/authStore'

export function AppShell() {
  const navigate = useNavigate()
  const user = useAuthStore((state) => state.user)
  const logout = useAuthStore((state) => state.logout)

  function handleLogout() {
    logout()
    navigate('/login', { replace: true })
  }

  return (
    <div className="flex min-h-screen bg-slate-100" dir="rtl">
      <Sidebar />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-20 items-center justify-between border-b border-slate-200 bg-white/90 px-6 backdrop-blur">
          <div className="space-y-1">
            <p className="text-sm text-slate-500">مرحباً بك</p>
            <p className="font-semibold text-slate-900">{user?.name}</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden rounded-2xl bg-slate-100 px-4 py-2 text-sm text-slate-600 md:block">
              {user?.email}
            </div>
            <button
              type="button"
              onClick={handleLogout}
              className="rounded-2xl bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              تسجيل الخروج
            </button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
